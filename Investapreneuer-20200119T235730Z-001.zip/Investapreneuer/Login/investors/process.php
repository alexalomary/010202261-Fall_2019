<?php
session_start();

$mysqli = new mysqli ("localhost", "root", "", "registration") or die(mysqli_error($mysqli));
$update = false;
$project_name='';
$project_description='';
$project_id = 0;
$project_category='';
$project_fund='';
if(isset($_POST['save'])){
  $project_name = $_POST['project_name'];
  $project_description = $_POST['project_description'];
  $project_category = $_POST['project_category'];
    $project_fund = $_POST['project_fund'];


  $mysqli->query("INSERT INTO projects (project_name, project_description, project_category, project_fund) VALUES ('$project_name', '$project_description', '$project_category', '$project_fund')") or die($mysqli->error);
  $_SESSION['message'] = "You signed up successfully!";
  $_SESSION['msg_type'] = "primary";

  header("location: index.php");
}
if(isset($_GET['delete'])){
  $project_id = $_GET['delete'];
  $mysqli->query("DELETE from projects WHERE project_id=$project_id") or die($mysqli->error());

  $_SESSION['message'] = "Record has been deleted!";
  $_SESSION['msg_type'] = "danger";

    header("location: index.php");
}

if(isset($_GET['edit'])){
  $project_id = $_GET['edit'];
  $update = true;
  $result = $mysqli->query("SELECT * FROM projects WHERE project_id=$project_id") or die($mysqli->error());

  if(count($result)==1){
    $row = $result->fetch_array();
    $project_name = $row['project_name'];
    $project_description = $row['project_description'];
    $project_category = $row['project_category'];
    $project_fund = $row['project_fund'];
  }
}
if (isset($_POST['update'])){
  $project_id = $_POST['project_id'];
  $project_name = $_POST ['project_name'];
  $project_description = $_POST['project_description'];
  $project_category = $_POST['project_category'];
  $project_fund = $_POST['project_fund'];

  $mysqli->query("UPDATE projects SET project_name = '$project_name', project_description = '$project_description', project_category = '$project_category', project_fund = '$project_fund', image = '$image' WHERE project_id=$project_id") or die($mysqli->error);

  $_SESSION['message'] = "Record has been updated!";
  $_SESSION['msg_type'] = "warning";

  header('location: index.php');
}
